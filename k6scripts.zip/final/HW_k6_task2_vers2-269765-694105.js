import http from 'k6/http';
import { group } from 'k6';
import { Trend } from 'k6/metrics';

const BASE_URL_1 = 'https://ya.ru'
const BASE_URL_2 = 'http://www.ru'


export const options = {
    scenarios:{
        LoadYa: {
            executor: 'ramping-arrival-rate',
            startRate: 0,
            exec: 'getYa',
            preAllocatedVUs: 50, 
            maxVUs: 100,
            timeUnit: '1m',
            stages: [
                {duration: '5m', target: 60},
                {duration: '10m', target: 60},
                {duration: '5m', target: 72},
                {duration: '10m', target: 72}
             ]
        },
        LoadRu: {
            executor: 'ramping-arrival-rate',
            startRate: 0,
            exec: 'getRu',
            preAllocatedVUs: 50, 
            maxVUs: 120,
            timeUnit: '1m',
            stages: [
                {duration: '5m', target: 120},
                {duration: '10m', target: 120},
                {duration: '5m', target: 144},
                {duration: '10m', target: 144}
             ]
            
        }
    }
}

export function getYa (){
    group('getYa', () => {
        http.get(`${BASE_URL_1}`)
    })
}

export function getRu(){
    group('getRu', () => {
        http.get(`${BASE_URL_2}`)
   })
}