import {  group, check } from 'k6';
import http from 'k6/http';
import { SharedArray } from 'k6/data';
import { randomItem } from 'https://jslib.k6.io/k6-utils/1.2.0/index.js';

const BASE_URL = 'http://webtours.load-test.ru:1080'
const ACCEPT = 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8';
const ACCEPT_ROOT = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7';
const ACCEPT_ENCODING = 'gzip, deflate';
const ACCEPT_LANGUAGE = 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36';
const CACHE_CONTROL = 'max-age=0';
const CONNECTION = 'keep-alive';
const USERNAME = 'jojo';
const PASS = '1234'


export const getRandomTown = () => {
    const towns =
    [
        'Denver', 'Frankfurt', 'London', 'Los Angeles', 'Paris', 'Portland', 'San Francisco', 'Seattle',
        'Sydney', 'Zurich'
    ]
    return towns[Math.floor(Math.random() * towns.length)]
}

const options = {}

let numFlight

export default function () {
    getRoot();
    postLogin();
    getFlights();
    postFindFlight();
    postSelectFlight();
    postPayment();
    getHome();
};

export function getRoot () {

  const result = group('RootPage', () =>
  {
    http.get(`${BASE_URL}/webtours/`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        'Cache-Control': `${CACHE_CONTROL}`,
        Connection: `${CONNECTION}`,
        Cookie: 'MSO=SID&1687039161',
        Host: 'webtours.load-test.ru:1080',
       // 'If-Modified-Since': 'Mon, 27 May 2013 12:20:22 GMT',
       // 'If-None-Match': '"900000001a214-16e-4ddb22c2e6d80"',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/webtours/header.html`, {
      headers: {
        Referer: 'http://webtours.load-test.ru:1080/webtours/',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/cgi-bin/welcome.pl?signOff=true`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie: 'MSO=SID&1687039161',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/webtours/`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/webtours/images/hp_logo.png`, {
      headers: {
        Referer: `${BASE_URL}/webtours/header.html`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/webtours/images/webtours.png`, {
      headers: {
        Referer: `${BASE_URL}/webtours/header.html`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    const response = http.get(`${BASE_URL}/cgi-bin/nav.pl?in=home`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie: 'MSO=SID&1687039173',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/welcome.pl?signOff=true`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    const template = response.body
    const rx = /name="userSession" value="([^"]+)"/
    const userSessionNum = template.match(rx)[1]
    http.get(`${BASE_URL}/WebTours/home.html`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/welcome.pl?signOff=true`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })
    http.get(`${BASE_URL}/WebTours/images/mer_login.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    return userSessionNum

  })

   return result
 }

 export function postLogin(){
  const userSessionNum = getRoot()
  
  group('Login', ()=> 
{    http.post(
      `${BASE_URL}/cgi-bin/login.pl`,
      {
        userSession: userSessionNum,
        username: `${USERNAME}`,
        password: `${PASS}`,
        'login.x': '66',
        'login.y': '9',
        JSFormSubmit: 'off',
      },
      {
        headers: {
          Accept: `${ACCEPT_ROOT}`,
          'Accept-Encoding': `${ACCEPT_ENCODING}`,
          'Accept-Language': `${ACCEPT_LANGUAGE}`,
          'Cache-Control': `${CACHE_CONTROL}`,
          Connection: `${CONNECTION}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          Cookie: 'MSO=SID&1687039173',
          Host: 'webtours.load-test.ru:1080',
          Origin: `${BASE_URL}`,
          Referer: `${BASE_URL}/cgi-bin/nav.pl?in=home`,
          'Upgrade-Insecure-Requests': '1',
          'User-Agent': `${USER_AGENT}`,
        },
      }
    )
    console.log(userSessionNum, 'postLogin')
    http.get(`${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/login.pl`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/cgi-bin/login.pl?intro=true`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/login.pl`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/flights.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/itinerary.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/in_home.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/signoff.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })
  })
 }

 export function getFlights(){
  group('Flights', ()=> {
    http.get(`${BASE_URL}/cgi-bin/welcome.pl?page=search`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/cgi-bin/nav.pl?page=menu&in=flights`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/welcome.pl?page=search`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/cgi-bin/reservations.pl?page=welcome`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/welcome.pl?page=search`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/in_flights.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=flights`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/itinerary.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=flights`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/home.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=flights`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/signoff.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=flights`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/button_next.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/reservations.pl?page=welcome`,
        'User-Agent': `${USER_AGENT}`,
      },
    })
  })
 } 

const getOutboundFlights = () => {
  const response = http.post(
    `${BASE_URL}/cgi-bin/reservations.pl`,
    ` TESTadvanceDiscount=0&depart=${getRandomTown()}&departDate=06%2F21%2F2023&arrive=${getRandomTown()}
      &returnDate=06%2F22%2F2023&numPassengers=1
      &seatPref=None&seatType=Coach&findFlights.x=68
      &findFlights.y=10&.cgifields=roundtrip%2CseatType%2CseatPref`,
    {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
          'Accept-Encoding': `${ACCEPT_ENCODING}`,
          'Accept-Language': `${ACCEPT_LANGUAGE}`,
          'Cache-Control': `${CACHE_CONTROL}`,
          Connection: `${CONNECTION}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          Cookie:
            'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
          Host: 'webtours.load-test.ru:1080',
          Origin: `${BASE_URL}`,
          Referer: `${BASE_URL}/cgi-bin/reservations.pl?page=welcome`,
          'Upgrade-Insecure-Requests': '1',
          'User-Agent': `${USER_AGENT}`,
      },
    }
  )

  const template = response.body
  const regexp = /name="outboundFlight" value="(.*?)"/g;
  const result = [...template.matchAll(regexp)]
  const mappedResult = result.map(item => item[1])
  const outboundFlight = getRandomElement(mappedResult)

function getRandomElement(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

  return outboundFlight

}

 export function postFindFlight(){
  group('findFlight', ()=> {
  numFlight = getOutboundFlights()
    http.get(`${BASE_URL}/WebTours/images/button_next.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/reservations.pl`,
        'User-Agent': `${USER_AGENT}`,
      },
    })
  })
 }
 export function postSelectFlight(){
  group('selectFlight', ()=> {
    console.warn(numFlight)
    http.post(
      `${BASE_URL}/cgi-bin/reservations.pl`,
      {
        outboundFlight: numFlight,
        numPassengers: '1',
        advanceDiscount: '0',
        seatType: 'Coach',
        seatPref: 'None',
        'reserveFlights.x': '29',
        'reserveFlights.y': '14',
      },
      {
        headers: {
          Accept: `${ACCEPT_ROOT}`,
          'Accept-Encoding': `${ACCEPT_ENCODING}`,
          'Accept-Language': `${ACCEPT_LANGUAGE}`,
          'Cache-Control': `${CACHE_CONTROL}`,
          Connection: `${CONNECTION}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          Cookie:
            'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
          Host: 'webtours.load-test.ru:1080',
          Origin: `${BASE_URL}`,
          Referer: `${BASE_URL}/cgi-bin/reservations.pl`,
          'Upgrade-Insecure-Requests': '1',
          'User-Agent': `${USER_AGENT}`,
        },
      }
    )

    http.get(`${BASE_URL}/WebTours/images/button_next.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/reservations.pl`,
        'User-Agent': `${USER_AGENT}`,
      },
    })
  })
 }

 export function postPayment(){ 
  group('Payment', ()=> {
    http.post(
      `${BASE_URL}/cgi-bin/reservations.pl`,
      {
        firstName: 'jojo',
        lastName: 'nataly',
        address1: 'aaa',
        address2: 'Moskow',
        pass1: 'jojo+nataly',
        creditCard: '',
        expDate: '',
        oldCCOption: '',
        numPassengers: '1',
        seatType: 'Coach',
        seatPref: 'None',
        outboundFlight: numFlight,
        advanceDiscount: '0',
        returnFlight: '',
        JSFormSubmit: 'off',
        'buyFlights.x': '34',
        'buyFlights.y': '7',
        '.cgifields': 'saveCC',
      },
      {
        headers: {
          Accept: `${ACCEPT_ROOT}`,
          'Accept-Encoding': `${ACCEPT_ENCODING}`,
          'Accept-Language': `${ACCEPT_LANGUAGE}`,
          'Cache-Control': `${CACHE_CONTROL}`,
          Connection: `${CONNECTION}`,
          'Content-Type': 'application/x-www-form-urlencoded',
          Cookie:
            'MSO=SID&1687039173; MTUserInfo=firstName&jojo&address2&Moskow&username&jojo&hash&78&lastName&nataly%0A&address1&aaa&creditCard&&expDate&%0A',
          Host: 'webtours.load-test.ru:1080',
          Origin: `${BASE_URL}`,
          Referer: `${BASE_URL}/cgi-bin/reservations.pl`,
          'Upgrade-Insecure-Requests': '1',
          'User-Agent': `${USER_AGENT}`,
        },
      }
    )

    http.get(`${BASE_URL}/WebTours/images/bookanother.gif`, {
      headers: {
        Accept: `${ACCEPT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&username&jojo&address2&Moskow&hash&78&address1&aaa&lastName&nataly%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/reservations.pl`,
        'User-Agent': `${USER_AGENT}`,
      },
    })
  })
 }

 export function getHome(){
  group('inHome', ()=> {
  http.get(`${BASE_URL}/cgi-bin/welcome.pl?page=menus`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&username&jojo&address2&Moskow&hash&78&address1&aaa&lastName&nataly%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=flights`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&username&jojo&address2&Moskow&hash&78&address1&aaa&lastName&nataly%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/welcome.pl?page=menus`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/cgi-bin/login.pl?intro=true`, {
      headers: {
        Accept: `${ACCEPT_ROOT}`,
        'Accept-Encoding': `${ACCEPT_ENCODING}`,
        'Accept-Language': `${ACCEPT_LANGUAGE}`,
        Connection: `${CONNECTION}`,
        Cookie:
          'MSO=SID&1687039173; MTUserInfo=firstName&jojo&username&jojo&address2&Moskow&hash&78&address1&aaa&lastName&nataly%0A',
        Host: 'webtours.load-test.ru:1080',
        Referer: `${BASE_URL}/cgi-bin/welcome.pl?page=menus`,
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/flights.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

    http.get(`${BASE_URL}/WebTours/images/itinerary.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

   http.get(`${BASE_URL}/WebTours/images/in_home.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })

   http.get(`${BASE_URL}/WebTours/images/signoff.gif`, {
      headers: {
        Referer: `${BASE_URL}/cgi-bin/nav.pl?page=menu&in=home`,
        'User-Agent': `${USER_AGENT}`,
      },
    })
  })  
 }
