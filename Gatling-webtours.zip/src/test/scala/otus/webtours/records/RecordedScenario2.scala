package otus.webtours.records

import scala.concurrent.duration._

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.jdbc.Predef._

class RecordedScenario2 extends Simulation {

  private val httpProtocol = http
    .baseUrl("http://webtours.load-test.ru:1080")
    .inferHtmlResources(AllowList(), DenyList(""".*\.js""", """.*\.css""", """.*\.gif""", """.*\.jpeg""", """.*\.jpg""", """.*\.ico""", """.*\.woff""", """.*\.woff2""", """.*\.(t|o)tf""", """.*\.png""", """.*\.svg""", """.*detectportal\.firefox\.com.*"""))
  
  private val headers_0 = Map(
  		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  		"Accept-Encoding" -> "gzip, deflate",
  		"Accept-Language" -> "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
  		"Cache-Control" -> "max-age=0",
  		"If-Modified-Since" -> "Mon, 27 May 2013 12:20:22 GMT",
  		"If-None-Match" -> "900000001a214-16e-4ddb22c2e6d80",
  		"Upgrade-Insecure-Requests" -> "1",
  		"User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.57"
  )
  
  private val headers_2 = Map(
  		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  		"Accept-Encoding" -> "gzip, deflate",
  		"Accept-Language" -> "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
  		"Upgrade-Insecure-Requests" -> "1",
  		"User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.57"
  )
  
  private val headers_5 = Map(
  		"Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
  		"Accept-Encoding" -> "gzip, deflate",
  		"Accept-Language" -> "ru,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
  		"Cache-Control" -> "max-age=0",
  		"Origin" -> "http://webtours.load-test.ru:1080",
  		"Upgrade-Insecure-Requests" -> "1",
  		"User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 Edg/113.0.1774.57"
  )


  private val scn = scenario("RecordedScenario2")
    .exec(
      http("request_0:GET_http://webtours.load-test.ru:1080/webtours/")
        .get("/webtours/")
        .headers(headers_0)
        .resources(
          http("request_1:GET_http://webtours.load-test.ru:1080/webtours/header.html")
            .get("/webtours/header.html"),
          http("request_2:GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?signOff=true")
            .get("/cgi-bin/welcome.pl?signOff=true")
            .headers(headers_2),
          http("request_3:GET_http://webtours.load-test.ru:1080/WebTours/home.html")
            .get("/WebTours/home.html"),
          http("request_4:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?in=home")
            .get("/cgi-bin/nav.pl?in=home")
            .headers(headers_2)
        )
    )
    .pause(22)
    .exec(
      http("request_5:POST_http://webtours.load-test.ru:1080/cgi-bin/login.pl")
        .post("/cgi-bin/login.pl")
        .headers(headers_5)
        .formParam("userSession", "136566.39854192HActzDtpVcftcVtHpiAtHf")
        .formParam("username", "jojoka7")
        .formParam("password", "beanka7")
        .formParam("login.x", "54")
        .formParam("login.y", "5")
        .formParam("JSFormSubmit", "off")
        .resources(
          http("request_6:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?page=menu&in=home")
            .get("/cgi-bin/nav.pl?page=menu&in=home")
            .headers(headers_2),
          http("request_7:GET_http://webtours.load-test.ru:1080/cgi-bin/login.pl?intro=true")
            .get("/cgi-bin/login.pl?intro=true")
            .headers(headers_2)
        )
    )
    .pause(2)
    .exec(
      http("request_8:GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?page=search")
        .get("/cgi-bin/welcome.pl?page=search")
        .headers(headers_2)
        .resources(
          http("request_9:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?page=menu&in=flights")
            .get("/cgi-bin/nav.pl?page=menu&in=flights")
            .headers(headers_2),
          http("request_10:GET_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl?page=welcome")
            .get("/cgi-bin/reservations.pl?page=welcome")
            .headers(headers_2)
        )
    )
    .pause(29)
    .exec(
      http("request_11:POST_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl")
        .post("/cgi-bin/reservations.pl")
        .headers(headers_5)
        .formParam("advanceDiscount", "0")
        .formParam("depart", "Frankfurt")
        .formParam("departDate", "06/05/2023")
        .formParam("arrive", "London")
        .formParam("returnDate", "06/06/2023")
        .formParam("numPassengers", "1")
        .formParam("seatPref", "None")
        .formParam("seatType", "Coach")
        .formParam("findFlights.x", "62")
        .formParam("findFlights.y", "12")
        .formParam(".cgifields", "roundtrip")
        .formParam(".cgifields", "seatType")
        .formParam(".cgifields", "seatPref")
    )
    .pause(2)
    .exec(
      http("request_12:POST_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl")
        .post("/cgi-bin/reservations.pl")
        .headers(headers_5)
        .formParam("outboundFlight", "121;237;06/05/2023")
        .formParam("numPassengers", "1")
        .formParam("advanceDiscount", "0")
        .formParam("seatType", "Coach")
        .formParam("seatPref", "None")
        .formParam("reserveFlights.x", "21")
        .formParam("reserveFlights.y", "8")
    )
    .pause(6)
    .exec(
      http("request_13:POST_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl")
        .post("/cgi-bin/reservations.pl")
        .headers(headers_5)
        .formParam("firstName", "FirstName")
        .formParam("lastName", "SecondName")
        .formParam("address1", "Street")
        .formParam("address2", "City")
        .formParam("pass1", "FirstName SecondName")
        .formParam("creditCard", "123456")
        .formParam("expDate", "1234")
        .formParam("oldCCOption", "")
        .formParam("numPassengers", "1")
        .formParam("seatType", "Coach")
        .formParam("seatPref", "None")
        .formParam("outboundFlight", "121;237;06/05/2023")
        .formParam("advanceDiscount", "0")
        .formParam("returnFlight", "")
        .formParam("JSFormSubmit", "off")
        .formParam("buyFlights.x", "56")
        .formParam("buyFlights.y", "12")
        .formParam(".cgifields", "saveCC")
    )
    .pause(3)
    .exec(
      http("request_14:GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?page=menus")
        .get("/cgi-bin/welcome.pl?page=menus")
        .headers(headers_2)
        .resources(
          http("request_15:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?page=menu&in=home")
            .get("/cgi-bin/nav.pl?page=menu&in=home")
            .headers(headers_2),
          http("request_16:GET_http://webtours.load-test.ru:1080/cgi-bin/login.pl?intro=true")
            .get("/cgi-bin/login.pl?intro=true")
            .headers(headers_2)
        )
    )

	setUp(scn.inject(atOnceUsers(1))).protocols(httpProtocol)
}
