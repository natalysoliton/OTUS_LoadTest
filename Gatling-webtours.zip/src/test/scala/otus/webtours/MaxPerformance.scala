package otus.webtours

import io.gatling.core.Predef._
import ru.tinkoff.gatling.config.SimulationConfig._
import ru.tinkoff.gatling.influxdb.Annotations
import otus.webtours.scenarios._

class MaxPerformance extends Simulation with Annotations {

  setUp(
    HttpScenario().inject(
      // интенсивность на ступень
      incrementUsersPerSec((intensity / stagesNumber)) // OpenedLoop
//      incrementConcurrentUsers((intensity / stagesNumber).toInt)  // ClosedLoop
        // Количество ступеней
        .times(stagesNumber)
        // Длительность полки
        .eachLevelLasting(stageDuration)
        // Длительность разгона
        .separatedByRampsLasting(rampDuration)
        // Начало нагрузки с
        .startingFrom(0),
    ),
  ).protocols(
    httpProtocol,
    // общая длительность теста
  ).maxDuration(testDuration)
//    .assertions(global.responseTime.max.lt(3000))
    .assertions(global.responseTime.percentile(95).lt(3000))
    .assertions(forAll.failedRequests.percent.lte(5))
}
