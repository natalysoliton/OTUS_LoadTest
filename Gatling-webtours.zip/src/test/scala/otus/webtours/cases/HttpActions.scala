package otus.webtours.cases

import io.gatling.http.Predef._
import io.gatling.core.Predef._
import io.gatling.http.request.builder
import io.gatling.http.request.builder.HttpRequestBuilder

object HttpActions {

  private val headers_0 = Map(
    "Cache-Control" -> "max-age=0",
    "If-Modified-Since" -> "Mon, 27 May 2013 12:20:22 GMT",
    "If-None-Match" -> "900000001a214-16e-4ddb22c2e6d80",
  )

  private val headers_5 = Map(
    "Cache-Control" -> "max-age=0",
    "Origin" -> "http://webtours.load-test.ru:1080",
  )

  val getMainPage: HttpRequestBuilder = http("request_0:GET_http://webtours.load-test.ru:1080/webtours/")
    .get("/webtours/")
    .check(css("title").is("Web Tours"))
//    .headers(headers_0)
    .resources(
      http("request_1:GET_http://webtours.load-test.ru:1080/webtours/header.html")
        .get("/webtours/header.html"),
//      http("request_2:GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?signOff=true")
//        .get("/cgi-bin/welcome.pl?signOff=true")
//        .check(css("title").is("Web Tours")),
//      http("request_3:GET_http://webtours.load-test.ru:1080/WebTours/home.html")
//        .get("/WebTours/home.html")
//        .check(css("title").is("Web Tours")),
//      http("request_4:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?in=home")
//        .get("/cgi-bin/nav.pl?in=home")
//        .check(css("title").is("Web Tours Navigation Bar"))
//        .check(regex("""name="userSession" value="(.+)"""").saveAs("userSession")),
    )

  val getMainPageResources: builder.HttpRequestBuilder = http(
    "request_2:GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?signOff=true")
    .get("/cgi-bin/welcome.pl?signOff=true")
    .check(css("title").is("Web Tours"))
    .resources(
      http("request_3:GET_http://webtours.load-test.ru:1080/WebTours/home.html")
        .get("/WebTours/home.html")
        .check(css("title").is("Web Tours")),
      http("request_4:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?in=home")
        .get("/cgi-bin/nav.pl?in=home")
        .check(css("title").is("Web Tours Navigation Bar"))
        .check(regex("""name="userSession" value="(.+)"""").saveAs("userSession")),
    )

  val login: HttpRequestBuilder = http("request_5:POST_http://webtours.load-test.ru:1080/cgi-bin/login.pl")
    .post("/cgi-bin/login.pl")
//    .headers(headers_5)
    .formParam("userSession", "#{userSession}")
    .formParam("username", "#{login}")
    .formParam("password", "#{password}")
    .formParam("login.x", "54")
    .formParam("login.y", "5")
    .formParam("JSFormSubmit", "off")
    .check(css("title").is("Web Tours"))
    .resources(
      http("request_6:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?page=menu&in=home")
        .get("/cgi-bin/nav.pl?page=menu&in=home")
        .check(css("title").is("Web Tours Navigation Bar")),
      http("request_7:GET_http://webtours.load-test.ru:1080/cgi-bin/login.pl?intro=true")
        .get("/cgi-bin/login.pl?intro=true")
        .check(css("title").is("Welcome to Web Tours"))
    )

  val flights: HttpRequestBuilder = http("request_8:" +
    "GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?page=search")
    .get("/cgi-bin/welcome.pl?page=search")
    .resources(
      http("request_9:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?page=menu&in=flights")
        .get("/cgi-bin/nav.pl?page=menu&in=flights"),
      http("request_10:GET_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl?page=welcome")
        .get("/cgi-bin/reservations.pl?page=welcome")
        .check(css("select[name=depart] option").findRandom.saveAs("departCity"))
        .check(css("select[name=arrive] option").findRandom.saveAs("arriveCity"))
    )

  val findFlights: HttpRequestBuilder = http("request_11:" +
    "POST_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl")
    .post("/cgi-bin/reservations.pl")
//    .headers(headers_5)
    .formParam("advanceDiscount", "0")
    .formParam("depart", "#{departCity}")
    .formParam("departDate", "06/25/2023")
    .formParam("arrive", "#{arriveCity}")
    .formParam("returnDate", "06/25/2023")
    .formParam("numPassengers", "1")
    .formParam("seatPref", "None")
    .formParam("seatType", "Coach")
    .formParam("findFlights.x", "62")
    .formParam("findFlights.y", "12")
    .formParam(".cgifields", "roundtrip")
    .formParam(".cgifields", "seatType")
    .formParam(".cgifields", "seatPref")
    .check(regex("""name="outboundFlight" value="(\d*;\d*;[\d\/]*)"""").findRandom.saveAs("outboundFlight"))

  val reserveFlights: HttpRequestBuilder = http("request_12:" +
    "POST_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl")
    .post("/cgi-bin/reservations.pl")
//    .headers(headers_5)
    .formParam("outboundFlight", "#{outboundFlight}")
    .formParam("numPassengers", "1")
    .formParam("advanceDiscount", "0")
    .formParam("seatType", "Coach")
    .formParam("seatPref", "None")
    .formParam("reserveFlights.x", "21")
    .formParam("reserveFlights.y", "8")
    .check(css("title").is("Flight Reservation"))

  val buyFlights: HttpRequestBuilder = http("request_13:" +
    "POST_http://webtours.load-test.ru:1080/cgi-bin/reservations.pl")
    .post("/cgi-bin/reservations.pl")
//    .headers(headers_5)
    .formParam("firstName", "FirstName")
    .formParam("lastName", "SecondName")
    .formParam("address1", "Street")
    .formParam("address2", "City")
    .formParam("pass1", "FirstName SecondName")
    .formParam("creditCard", "123456")
    .formParam("expDate", "1234")
    .formParam("oldCCOption", "")
    .formParam("numPassengers", "1")
    .formParam("seatType", "Coach")
    .formParam("seatPref", "None")
    .formParam("outboundFlight", "#{outboundFlight}")
    .formParam("advanceDiscount", "0")
    .formParam("returnFlight", "")
    .formParam("JSFormSubmit", "off")
    .formParam("buyFlights.x", "56")
    .formParam("buyFlights.y", "12")
    .formParam(".cgifields", "saveCC")
    .check(css("title").is("Reservation Made!"))

  val goHome: HttpRequestBuilder = http("request_14:" +
    "GET_http://webtours.load-test.ru:1080/cgi-bin/welcome.pl?page=menus")
    .get("/cgi-bin/welcome.pl?page=menus")
    .check(css("title").is("Web Tours"))
    .resources(
      http("request_15:GET_http://webtours.load-test.ru:1080/cgi-bin/nav.pl?page=menu&in=home")
        .get("/cgi-bin/nav.pl?page=menu&in=home")
        .check(css("title").is("Web Tours Navigation Bar")),
      http("request_16:GET_http://webtours.load-test.ru:1080/cgi-bin/login.pl?intro=true")
        .get("/cgi-bin/login.pl?intro=true")
        .check(css("title").is("Welcome to Web Tours"))
    )

}
