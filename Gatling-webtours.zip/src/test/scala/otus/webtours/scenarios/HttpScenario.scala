package otus.webtours.scenarios

import io.gatling.core.Predef._
import io.gatling.core.structure.{ChainBuilder, ScenarioBuilder}
import otus.webtours.cases._
import otus.webtours.Feeders._

import io.gatling.http.Predef._

object HttpScenario {
  def apply(): ScenarioBuilder = new HttpScenario().scn
}

class HttpScenario {

  val scn: ScenarioBuilder = scenario("Http Scenario")
    .feed(users)
    .group("getMainPage") {
      exec(HttpActions.getMainPage)
        .exec(HttpActions.getMainPageResources)
    }
    .pause(1, 3)
    .exec(HttpActions.login)
    .pause(1, 3)
    .exec(HttpActions.flights)
    .pause(1, 3)
    .exec(HttpActions.findFlights)
    .pause(1, 3)
    .exec(HttpActions.reserveFlights)
    .pause(1, 3)
    .exec(HttpActions.buyFlights)
    .pause(1, 3)
    .exec(HttpActions.goHome)
}
